#!/usr/bin/env python3
"""
DocuExtract — PDF Field Extraction using Azure Document Intelligence
=====================================================================
Usage:
    python main.py --endpoint <URL> --key <KEY> --excel headings.xlsx --pdfs file1.pdf file2.pdf
    python main.py --config config.json --pdfs *.pdf
    python main.py --help
"""

import argparse
import json
import sys
import os
from pathlib import Path

from core.extractor import AzureDocumentExtractor
from core.excel_reader import read_headings_from_excel
from core.matcher import match_headings_to_results
from output.excel_writer import write_results_to_excel
from output.csv_writer import write_results_to_csv
from utils.logger import get_logger

logger = get_logger(__name__)


def parse_args():
    parser = argparse.ArgumentParser(
        description="Extract structured fields from PDFs using Azure Document Intelligence",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Basic usage
  python main.py --endpoint https://myresource.cognitiveservices.azure.com/ \\
                 --key YOUR_KEY \\
                 --excel headings.xlsx \\
                 --pdfs report1.pdf report2.pdf

  # Using config file
  python main.py --config config.json --pdfs *.pdf

  # Specify sheet and column
  python main.py --endpoint URL --key KEY \\
                 --excel headings.xlsx --sheet "Fields" --col A \\
                 --pdfs report.pdf --output results.xlsx

  # Export both Excel and CSV
  python main.py --config config.json --pdfs *.pdf --format both
        """
    )

    # Azure credentials
    creds = parser.add_argument_group("Azure Credentials")
    creds.add_argument("--endpoint", help="Azure Document Intelligence endpoint URL")
    creds.add_argument("--key", help="Azure Document Intelligence API key")
    creds.add_argument("--model", default="prebuilt-layout",
                       choices=["prebuilt-layout", "prebuilt-document", "prebuilt-read"],
                       help="Azure model to use (default: prebuilt-layout)")

    # Config file alternative
    parser.add_argument("--config", help="Path to JSON config file (alternative to --endpoint/--key)")

    # Excel headings
    excel_group = parser.add_argument_group("Excel Headings")
    excel_group.add_argument("--excel", required=True, help="Excel file containing field headings")
    excel_group.add_argument("--sheet", default=None, help="Sheet name (default: first sheet)")
    excel_group.add_argument("--col", default=None, help="Column letter with headings e.g. A (default: auto-detect)")
    excel_group.add_argument("--header-row", type=int, default=1,
                             help="Row number where headings start (default: 1)")

    # PDFs
    parser.add_argument("--pdfs", nargs="+", required=True, help="PDF file(s) to process")

    # Output
    out_group = parser.add_argument_group("Output")
    out_group.add_argument("--output", default="DocuExtract_Results.xlsx",
                           help="Output file path (default: DocuExtract_Results.xlsx)")
    out_group.add_argument("--format", default="excel",
                           choices=["excel", "csv", "both"],
                           help="Output format (default: excel)")
    out_group.add_argument("--threshold", type=float, default=0.3,
                           help="Confidence threshold 0-1 (default: 0.3)")

    # Misc
    parser.add_argument("--verbose", action="store_true", help="Verbose logging")
    parser.add_argument("--dry-run", action="store_true",
                        help="Read headings and validate files but don't call Azure")

    return parser.parse_args()


def load_config(config_path: str) -> dict:
    with open(config_path) as f:
        return json.load(f)


def resolve_credentials(args) -> tuple[str, str]:
    """Get endpoint and key from args or config file or environment variables."""
    endpoint = args.endpoint or os.environ.get("AZURE_DOC_ENDPOINT")
    key = args.key or os.environ.get("AZURE_DOC_KEY")

    if args.config:
        cfg = load_config(args.config)
        endpoint = endpoint or cfg.get("endpoint")
        key = key or cfg.get("key")

    if not endpoint:
        logger.error("Azure endpoint not provided. Use --endpoint, --config, or set AZURE_DOC_ENDPOINT env var.")
        sys.exit(1)
    if not key:
        logger.error("Azure key not provided. Use --key, --config, or set AZURE_DOC_KEY env var.")
        sys.exit(1)

    return endpoint.rstrip("/"), key


def validate_files(pdf_paths: list[str]) -> list[Path]:
    """Validate all PDF files exist and are readable."""
    valid = []
    for p in pdf_paths:
        path = Path(p)
        if not path.exists():
            logger.warning(f"File not found, skipping: {p}")
        elif not path.suffix.lower() == ".pdf":
            logger.warning(f"Not a PDF file, skipping: {p}")
        elif path.stat().st_size == 0:
            logger.warning(f"Empty file, skipping: {p}")
        else:
            valid.append(path)
    if not valid:
        logger.error("No valid PDF files to process.")
        sys.exit(1)
    return valid


def main():
    args = parse_args()

    if args.verbose:
        import logging
        logging.getLogger().setLevel(logging.DEBUG)

    # ── Resolve credentials ──
    if not args.dry_run:
        endpoint, key = resolve_credentials(args)
        model = args.model
    else:
        endpoint, key, model = "DRY_RUN", "DRY_RUN", args.model

    # ── Read headings from Excel ──
    logger.info(f"Reading headings from: {args.excel}")
    headings = read_headings_from_excel(
        path=args.excel,
        sheet_name=args.sheet,
        col_letter=args.col,
        header_row=args.header_row,
    )
    logger.info(f"  → {len(headings)} unique headings found")
    if args.verbose:
        for h in headings:
            logger.debug(f"     • {h}")

    if not headings:
        logger.error("No headings found in Excel file. Check --sheet and --col arguments.")
        sys.exit(1)

    # ── Validate PDFs ──
    pdf_paths = validate_files(args.pdfs)
    logger.info(f"PDFs to process: {len(pdf_paths)}")

    if args.dry_run:
        logger.info("Dry run complete. Not calling Azure.")
        print(f"\nHeadings ({len(headings)}):")
        for h in headings:
            print(f"  • {h}")
        print(f"\nPDFs ({len(pdf_paths)}):")
        for p in pdf_paths:
            print(f"  • {p.name}")
        return

    # ── Extract from each PDF ──
    extractor = AzureDocumentExtractor(endpoint=endpoint, key=key, model=model)
    all_results = {}

    for i, pdf_path in enumerate(pdf_paths, 1):
        logger.info(f"\n[{i}/{len(pdf_paths)}] Processing: {pdf_path.name}")
        try:
            analyze_result = extractor.analyze_pdf(pdf_path)
            rows = match_headings_to_results(
                headings=headings,
                analyze_result=analyze_result,
                threshold=args.threshold,
            )
            matched = sum(1 for r in rows if r["value"])
            logger.info(f"  → Matched {matched}/{len(headings)} fields")
            all_results[pdf_path.name] = rows
        except Exception as e:
            logger.error(f"  ✗ Failed: {e}")
            all_results[pdf_path.name] = [
                {"field": h, "value": f"ERROR: {e}", "confidence": 0, "source": "", "page": ""} 
                for h in headings
            ]

    # ── Write output ──
    out_path = Path(args.output)

    if args.format in ("excel", "both"):
        excel_path = out_path.with_suffix(".xlsx")
        write_results_to_excel(all_results, excel_path)
        logger.info(f"\n✓ Excel saved: {excel_path}")

    if args.format in ("csv", "both"):
        csv_path = out_path.with_suffix(".csv")
        write_results_to_csv(all_results, csv_path)
        logger.info(f"✓ CSV saved: {csv_path}")

    # ── Summary ──
    print("\n" + "═" * 60)
    print("EXTRACTION SUMMARY")
    print("═" * 60)
    for pdf_name, rows in all_results.items():
        matched = sum(1 for r in rows if r["value"] and not str(r["value"]).startswith("ERROR"))
        pct = (matched / len(rows) * 100) if rows else 0
        print(f"  {pdf_name}")
        print(f"    {matched}/{len(rows)} fields matched ({pct:.0f}%)")
    print("═" * 60)


if __name__ == "__main__":
    main()
