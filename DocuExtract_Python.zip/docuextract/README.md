# DocuExtract — PDF Field Extraction via Azure Document Intelligence

Extract any set of fields from PDFs using headings defined in an Excel file.
Results are written back to a formatted Excel workbook (or CSV).

---

## Folder Structure

```
docuextract/
├── main.py                  ← Entry point (run this)
├── requirements.txt
├── config.json              ← Your Azure credentials (edit this)
│
├── core/
│   ├── extractor.py         ← Azure API calls (submit + poll)
│   ├── excel_reader.py      ← Read headings from Excel
│   └── matcher.py           ← Match headings to Azure results
│
├── output/
│   ├── excel_writer.py      ← Write formatted Excel output
│   └── csv_writer.py        ← Write CSV output
│
└── utils/
    └── logger.py            ← Logging setup
```

---

## Setup

```bash
pip install -r requirements.txt
```

---

## Configuration

Edit `config.json`:

```json
{
  "endpoint": "https://YOUR-RESOURCE.cognitiveservices.azure.com/",
  "key": "YOUR_API_KEY",
  "model": "prebuilt-layout"
}
```

Or use environment variables:
```bash
export AZURE_DOC_ENDPOINT="https://..."
export AZURE_DOC_KEY="abc123..."
```

---

## Usage

### Basic — using config file
```bash
python main.py --config config.json \
               --excel headings.xlsx \
               --pdfs report1.pdf report2.pdf
```

### Specifying credentials directly
```bash
python main.py \
  --endpoint https://myresource.cognitiveservices.azure.com/ \
  --key YOUR_KEY \
  --excel headings.xlsx \
  --pdfs *.pdf
```

### Custom sheet and column in Excel
```bash
python main.py --config config.json \
               --excel headings.xlsx \
               --sheet "DataFields" \
               --col B \
               --pdfs report.pdf
```

### Export both Excel and CSV
```bash
python main.py --config config.json \
               --excel headings.xlsx \
               --pdfs *.pdf \
               --format both \
               --output my_results
```

### Dry run (validate inputs without calling Azure)
```bash
python main.py --config config.json \
               --excel headings.xlsx \
               --pdfs *.pdf \
               --dry-run
```

### Verbose logging
```bash
python main.py --config config.json \
               --excel headings.xlsx \
               --pdfs report.pdf \
               --verbose
```

---

## Options Reference

| Option          | Default             | Description                                               |
|-----------------|---------------------|-----------------------------------------------------------|
| `--endpoint`    | —                   | Azure endpoint URL                                        |
| `--key`         | —                   | Azure API key                                             |
| `--model`       | `prebuilt-layout`   | Azure model: layout / document / read                     |
| `--config`      | —                   | Path to config.json (alternative to --endpoint/--key)     |
| `--excel`       | (required)          | Excel file with headings                                  |
| `--sheet`       | first sheet         | Sheet name inside Excel                                   |
| `--col`         | auto-detect         | Column letter (A, B, C…) containing headings              |
| `--header-row`  | 1                   | Row number where headings start                           |
| `--pdfs`        | (required)          | One or more PDF files                                     |
| `--output`      | `DocuExtract_Results.xlsx` | Output file path                                 |
| `--format`      | `excel`             | Output format: `excel`, `csv`, or `both`                  |
| `--threshold`   | `0.3`               | Minimum confidence threshold (0–1) to include a match     |
| `--verbose`     | off                 | Enable debug logging                                      |
| `--dry-run`     | off                 | Validate inputs only, don't call Azure                    |

---

## How Matching Works

For each heading from your Excel file, the matcher searches the Azure result in this priority order:

1. **Key-Value Pairs** — Azure's direct label:value extraction (highest confidence ~0.85)
2. **Table Column Headers** — column header → values in cells below (confidence ~0.78)
3. **Table Row Headers** — row label → values to the right (confidence ~0.72)
4. **Inline Patterns** — paragraphs matching `Label: Value` or `Label — Value` (confidence ~0.55)

The final match score = `similarity × source_confidence`. Set `--threshold` to control strictness.

---

## Output Excel Structure

| Sheet          | Contents                                         |
|----------------|--------------------------------------------------|
| `Summary`      | One row per PDF with match count and match rate  |
| `All Data`     | All PDFs combined (only if multiple PDFs)        |
| `<PDF name>`   | Individual sheet per PDF with full field table   |

Each row in the data sheets contains:
- **Field Name** — the heading from your Excel
- **Extracted Value** — the matched value from the PDF
- **Confidence** — color-coded percentage (green ≥80%, yellow ≥50%, red <50%)
- **Source / Type** — Key-Value Pair / Table / Inline Pattern
- **Page** — page number in the PDF

---

## Azure Models

| Model               | Best For                                                |
|---------------------|---------------------------------------------------------|
| `prebuilt-layout`   | General PDFs — extracts tables, key-values, paragraphs  |
| `prebuilt-document` | Forms and documents — focuses on key-value extraction   |
| `prebuilt-read`     | Plain text extraction only                              |

For most financial/clinical reports, use `prebuilt-layout` (default).
