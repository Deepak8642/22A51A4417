"""
output/excel_writer.py — Write extraction results to a formatted Excel file.

Output structure:
  Sheet "Summary"          — one row per PDF with match stats
  Sheet "All Data"         — all PDFs combined (if multiple PDFs)
  Sheet "<PDF name>"       — one sheet per PDF with full field table
"""

from pathlib import Path
from utils.logger import get_logger

logger = get_logger(__name__)


def write_results_to_excel(all_results: dict, out_path: Path):
    """
    Write all extraction results to an Excel workbook.

    Args:
        all_results: { pdf_filename: [row_dicts] }
        out_path:    Output .xlsx path.
    """
    try:
        from openpyxl import Workbook
        from openpyxl.styles import (
            Font, PatternFill, Alignment, Border, Side, GradientFill
        )
        from openpyxl.utils import get_column_letter
    except ImportError:
        raise ImportError("openpyxl is required: pip install openpyxl")

    wb = Workbook()
    wb.remove(wb.active)  # remove default sheet

    # ── Styles ──────────────────────────────────────────────────────────────
    DARK_BG    = "1A1A2E"
    ACCENT     = "6C63FF"
    ACCENT2    = "43E0A0"
    LIGHT_BG   = "F5F5FB"
    MED_GRAY   = "E8E8F0"
    TEXT_DARK  = "1A1A2E"
    TEXT_MID   = "555580"

    def header_style(cell, bg=ACCENT, fg="FFFFFF"):
        cell.font = Font(bold=True, color=fg, name="Calibri", size=11)
        cell.fill = PatternFill("solid", fgColor=bg)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = _thin_border()

    def data_style(cell, bg=None, wrap=False):
        cell.font = Font(name="Calibri", size=10, color=TEXT_DARK)
        if bg:
            cell.fill = PatternFill("solid", fgColor=bg)
        cell.alignment = Alignment(vertical="top", wrap_text=wrap)
        cell.border = _thin_border(light=True)

    def _thin_border(light=False):
        color = "D0D0E0" if light else "AAAACC"
        side = Side(style="thin", color=color)
        return Border(left=side, right=side, top=side, bottom=side)

    def conf_color(conf: float) -> str:
        if conf >= 0.8:  return "C8F5E3"  # green
        if conf >= 0.5:  return "FFF3C8"  # yellow
        if conf > 0:     return "FFD6DC"  # red-ish
        return "EBEBEB"                    # grey

    # ── Summary Sheet ────────────────────────────────────────────────────────
    ws_sum = wb.create_sheet("Summary")
    ws_sum.sheet_view.showGridLines = False
    ws_sum.row_dimensions[1].height = 32
    ws_sum.column_dimensions["A"].width = 42
    ws_sum.column_dimensions["B"].width = 16
    ws_sum.column_dimensions["C"].width = 14
    ws_sum.column_dimensions["D"].width = 14
    ws_sum.column_dimensions["E"].width = 20

    sum_headers = ["PDF File", "Fields Matched", "Total Fields", "Match Rate", "Status"]
    for ci, h in enumerate(sum_headers, 1):
        cell = ws_sum.cell(row=1, column=ci, value=h)
        header_style(cell, bg=DARK_BG)

    for ri, (pdf_name, rows) in enumerate(all_results.items(), 2):
        matched = sum(1 for r in rows if r.get("value") and not str(r.get("value","")).startswith("ERROR"))
        total   = len(rows)
        rate    = matched / total if total else 0
        status  = "✓ Good" if rate >= 0.7 else "⚠ Partial" if rate >= 0.3 else "✗ Low"

        row_bg = LIGHT_BG if ri % 2 == 0 else "FFFFFF"
        vals = [pdf_name, matched, total, rate, status]
        for ci, v in enumerate(vals, 1):
            cell = ws_sum.cell(row=ri, column=ci, value=v)
            data_style(cell, bg=row_bg)
            if ci == 1:
                cell.alignment = Alignment(vertical="top")
            if ci == 4:
                cell.number_format = "0.0%"
                cell.fill = PatternFill("solid", fgColor=conf_color(rate))
            if ci == 5:
                color = "1A7A4A" if rate >= 0.7 else "8B6000" if rate >= 0.3 else "7A1A2E"
                cell.font = Font(name="Calibri", size=10, bold=True, color=color)

    ws_sum["A1"].value = "📊 Extraction Summary"
    ws_sum.freeze_panes = "A2"

    # ── Per-PDF Sheets ───────────────────────────────────────────────────────
    COL_WIDTHS = [5, 38, 50, 14, 22, 8]
    HEADERS    = ["#", "Field Name (Heading)", "Extracted Value", "Confidence", "Source / Type", "Page"]

    # Combined sheet if multiple PDFs
    if len(all_results) > 1:
        ws_all = wb.create_sheet("All Data")
        ws_all.sheet_view.showGridLines = False
        all_col_widths = [32] + COL_WIDTHS
        all_headers = ["PDF File"] + HEADERS
        for ci, w in enumerate(all_col_widths, 1):
            ws_all.column_dimensions[get_column_letter(ci)].width = w
        ws_all.row_dimensions[1].height = 28
        for ci, h in enumerate(all_headers, 1):
            header_style(ws_all.cell(row=1, column=ci, value=h))
        ws_all.freeze_panes = "A2"

        global_ri = 2
        for pdf_name, rows in all_results.items():
            for i, r in enumerate(rows, 1):
                row_bg = LIGHT_BG if global_ri % 2 == 0 else "FFFFFF"
                vals = [pdf_name, i, r["field"], r["value"] or "—", r["confidence"], r["source"], r["page"]]
                for ci, v in enumerate(vals, 1):
                    cell = ws_all.cell(row=global_ri, column=ci, value=v)
                    data_style(cell, bg=row_bg, wrap=(ci == 4))
                    if ci == 5:  # confidence
                        cell.number_format = "0.0%"
                        if isinstance(v, float):
                            cell.fill = PatternFill("solid", fgColor=conf_color(v))
                global_ri += 1

    # Individual PDF sheets
    for pdf_name, rows in all_results.items():
        safe_name = _safe_sheet_name(pdf_name)
        ws = wb.create_sheet(safe_name)
        ws.sheet_view.showGridLines = False

        for ci, w in enumerate(COL_WIDTHS, 1):
            ws.column_dimensions[get_column_letter(ci)].width = w
        ws.row_dimensions[1].height = 28

        # Header row
        for ci, h in enumerate(HEADERS, 1):
            header_style(ws.cell(row=1, column=ci, value=h))

        ws.freeze_panes = "A2"

        # Data rows
        for ri, r in enumerate(rows, 2):
            row_bg = LIGHT_BG if ri % 2 == 0 else "FFFFFF"
            conf   = r.get("confidence", 0)
            vals   = [ri - 1, r["field"], r["value"] or "—", conf, r.get("source",""), r.get("page","")]

            for ci, v in enumerate(vals, 1):
                cell = ws.cell(row=ri, column=ci, value=v)
                data_style(cell, bg=row_bg, wrap=(ci == 3))

                # Row number — dim
                if ci == 1:
                    cell.font = Font(name="Calibri", size=9, color=TEXT_MID)
                    cell.alignment = Alignment(horizontal="center", vertical="top")

                # Field name — bold
                if ci == 2:
                    cell.font = Font(name="Calibri", size=10, bold=True, color=ACCENT.replace("FF","").ljust(6,"0"))

                # Value — wrap
                if ci == 3 and not r.get("value"):
                    cell.font = Font(name="Calibri", size=10, color="AAAACC", italic=True)

                # Confidence — color-coded
                if ci == 4 and isinstance(v, float):
                    cell.number_format = "0.0%"
                    cell.fill = PatternFill("solid", fgColor=conf_color(v))
                    cell.alignment = Alignment(horizontal="center", vertical="top")

    # ── Move Summary to first position ──────────────────────────────────────
    wb.move_sheet("Summary", offset=-len(wb.sheetnames))

    out_path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(out_path)
    logger.debug(f"  Saved workbook: {out_path}")


def _safe_sheet_name(name: str) -> str:
    """Make a valid Excel sheet name (max 31 chars, no special chars)."""
    import re
    name = re.sub(r"[:\\\/\?\*\[\]]", "_", name)
    name = name.replace(".pdf", "").replace(".PDF", "")
    return name[:31]
