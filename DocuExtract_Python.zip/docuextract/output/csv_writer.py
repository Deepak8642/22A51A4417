"""
output/csv_writer.py — Write extraction results to CSV.
"""

import csv
from pathlib import Path
from utils.logger import get_logger

logger = get_logger(__name__)


def write_results_to_csv(all_results: dict, out_path: Path):
    """
    Write all results to a single CSV file.

    Args:
        all_results: { pdf_filename: [row_dicts] }
        out_path:    Output .csv path.
    """
    out_path.parent.mkdir(parents=True, exist_ok=True)

    fieldnames = ["pdf_file", "row_num", "field_name", "extracted_value",
                  "confidence_pct", "source_type", "page"]

    with open(out_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()

        for pdf_name, rows in all_results.items():
            for i, r in enumerate(rows, 1):
                conf = r.get("confidence", 0)
                writer.writerow({
                    "pdf_file":        pdf_name,
                    "row_num":         i,
                    "field_name":      r.get("field", ""),
                    "extracted_value": r.get("value", ""),
                    "confidence_pct":  f"{conf * 100:.1f}%" if conf else "",
                    "source_type":     r.get("source", ""),
                    "page":            r.get("page", ""),
                })

    logger.debug(f"  Saved CSV: {out_path}")
