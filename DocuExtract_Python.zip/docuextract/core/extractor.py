"""
core/extractor.py — Azure Document Intelligence API calls
"""

import time
import requests
from pathlib import Path
from utils.logger import get_logger

logger = get_logger(__name__)

API_VERSION = "2023-07-31"
POLL_INTERVAL_SEC = 2
MAX_POLL_ATTEMPTS = 120  # 4 minutes max


class AzureDocumentExtractor:
    """
    Submits PDFs to Azure Document Intelligence and retrieves
    the full analyzeResult JSON.
    """

    def __init__(self, endpoint: str, key: str, model: str = "prebuilt-layout"):
        self.endpoint = endpoint.rstrip("/")
        self.key = key
        self.model = model
        self.session = requests.Session()
        self.session.headers.update({"Ocp-Apim-Subscription-Key": self.key})

    # ── Public ──────────────────────────────────────────────────────────────

    def analyze_pdf(self, pdf_path: Path) -> dict:
        """
        Full pipeline: upload PDF → poll until done → return analyzeResult dict.

        Args:
            pdf_path: Path to the PDF file.

        Returns:
            The analyzeResult dict from Azure (contains keyValuePairs, tables,
            paragraphs, pages, etc.)

        Raises:
            RuntimeError: If submission or analysis fails.
        """
        operation_url = self._submit(pdf_path)
        logger.debug(f"  Operation URL: {operation_url}")
        result = self._poll(operation_url, pdf_path.name)
        return result

    # ── Private ─────────────────────────────────────────────────────────────

    def _submit(self, pdf_path: Path) -> str:
        """POST the PDF to Azure and return the operation URL."""
        url = (
            f"{self.endpoint}/formrecognizer/documentModels"
            f"/{self.model}:analyze?api-version={API_VERSION}"
        )
        logger.debug(f"  Submitting to: {url}")

        with open(pdf_path, "rb") as f:
            data = f.read()

        resp = self.session.post(
            url,
            headers={"Content-Type": "application/pdf"},
            data=data,
            timeout=60,
        )

        if resp.status_code not in (200, 202):
            raise RuntimeError(
                f"Azure submission failed [{resp.status_code}]: {resp.text[:500]}"
            )

        operation_url = resp.headers.get("Operation-Location")
        if not operation_url:
            raise RuntimeError("No Operation-Location header in Azure response.")

        return operation_url

    def _poll(self, operation_url: str, filename: str) -> dict:
        """Poll the operation URL until succeeded or failed."""
        for attempt in range(1, MAX_POLL_ATTEMPTS + 1):
            time.sleep(POLL_INTERVAL_SEC)

            resp = self.session.get(operation_url, timeout=30)
            if resp.status_code != 200:
                raise RuntimeError(
                    f"Poll request failed [{resp.status_code}]: {resp.text[:300]}"
                )

            data = resp.json()
            status = data.get("status", "")

            elapsed = attempt * POLL_INTERVAL_SEC
            logger.debug(f"  [{elapsed}s] Status: {status}")

            if status == "succeeded":
                logger.info(f"  ✓ Analysis complete ({elapsed}s)")
                return data.get("analyzeResult", {})

            elif status == "failed":
                error = data.get("error", {})
                raise RuntimeError(
                    f"Azure analysis failed for {filename}: "
                    f"{error.get('code')} — {error.get('message')}"
                )

            # still running — show progress dot every 10s
            if elapsed % 10 == 0:
                logger.info(f"  ⏳ Still processing {filename}… ({elapsed}s)")

        raise RuntimeError(
            f"Timeout: Azure did not finish analyzing {filename} "
            f"within {MAX_POLL_ATTEMPTS * POLL_INTERVAL_SEC}s"
        )
