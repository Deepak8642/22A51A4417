"""
core/matcher.py — Match Excel headings to Azure Document Intelligence results.

Matching strategy (in order of priority):
  1. Key-Value pairs   — highest confidence, direct label:value
  2. Table column headers → cell values below
  3. Table row headers → cell values to the right
  4. Inline paragraph patterns — "Label: Value" or "Label — Value"
  5. Semantic fuzzy matching as fallback
"""

import re
from utils.logger import get_logger

logger = get_logger(__name__)


# ── Public ────────────────────────────────────────────────────────────────────

def match_headings_to_results(
    headings: list[str],
    analyze_result: dict,
    threshold: float = 0.3,
) -> list[dict]:
    """
    For each heading, find the best matching value in the Azure result.

    Args:
        headings:       List of field names from Excel.
        analyze_result: Full analyzeResult dict from Azure.
        threshold:      Minimum combined score to accept a match (0–1).

    Returns:
        List of dicts with keys: field, value, confidence, source, page, match_type
    """
    corpus = _build_corpus(analyze_result)
    logger.debug(f"  Corpus size: {len(corpus)} entries")

    results = []
    for heading in headings:
        match = _find_best_match(heading, corpus, threshold)
        if match:
            results.append({
                "field":      heading,
                "value":      match["value"],
                "confidence": round(match["score"], 3),
                "source":     match["type"],
                "page":       match.get("page", ""),
            })
        else:
            results.append({
                "field":      heading,
                "value":      "",
                "confidence": 0.0,
                "source":     "",
                "page":       "",
            })

    return results


# ── Corpus Builder ────────────────────────────────────────────────────────────

def _build_corpus(analyze_result: dict) -> list[dict]:
    """Build a unified list of candidate key→value pairs from all Azure output."""
    corpus = []
    corpus.extend(_extract_key_value_pairs(analyze_result))
    corpus.extend(_extract_table_column_pairs(analyze_result))
    corpus.extend(_extract_table_row_pairs(analyze_result))
    corpus.extend(_extract_inline_patterns(analyze_result))
    return corpus


def _extract_key_value_pairs(ar: dict) -> list[dict]:
    """Extract key-value pairs (Azure's direct KV extraction)."""
    items = []
    for kv in ar.get("keyValuePairs", []):
        key_content   = (kv.get("key")   or {}).get("content", "").strip()
        value_content = (kv.get("value") or {}).get("content", "").strip()
        if not key_content or not value_content:
            continue
        page = (
            ((kv.get("key") or {}).get("boundingRegions") or [{}])[0]
            .get("pageNumber", 1)
        )
        items.append({
            "key":        key_content,
            "value":      value_content,
            "confidence": kv.get("confidence", 0.85),
            "type":       "Key-Value Pair",
            "page":       page,
        })
    return items


def _extract_table_column_pairs(ar: dict) -> list[dict]:
    """Column headers → values in cells below them."""
    items = []
    for ti, table in enumerate(ar.get("tables", [])):
        cells = table.get("cells", [])
        # Build grid: (row, col) → cell
        grid = {}
        for cell in cells:
            grid[(cell["rowIndex"], cell["columnIndex"])] = cell

        # Find header row cells
        headers = [c for c in cells if c.get("kind") == "columnHeader" or c.get("rowIndex") == 0]
        for hc in headers:
            header_text = hc.get("content", "").strip()
            if not header_text:
                continue
            col = hc["columnIndex"]
            row_start = hc["rowIndex"] + 1

            # Collect all non-empty values in same column
            for r in range(row_start, table.get("rowCount", 0) + 1):
                vc = grid.get((r, col))
                if vc and vc.get("content", "").strip():
                    page = (hc.get("boundingRegions") or [{}])[0].get("pageNumber", 1)
                    items.append({
                        "key":        header_text,
                        "value":      vc["content"].strip(),
                        "confidence": 0.78,
                        "type":       f"Table-{ti+1} Column",
                        "page":       page,
                    })
    return items


def _extract_table_row_pairs(ar: dict) -> list[dict]:
    """Row headers (first column) → values to the right."""
    items = []
    for ti, table in enumerate(ar.get("tables", [])):
        cells = table.get("cells", [])
        grid = {}
        for cell in cells:
            grid[(cell["rowIndex"], cell["columnIndex"])] = cell

        row_headers = [c for c in cells if c.get("kind") == "rowHeader" or c.get("columnIndex") == 0]
        for hc in row_headers:
            header_text = hc.get("content", "").strip()
            if not header_text:
                continue
            row = hc["rowIndex"]
            col_start = hc["columnIndex"] + 1

            for c in range(col_start, table.get("columnCount", 0) + 1):
                vc = grid.get((row, c))
                if vc and vc.get("content", "").strip():
                    page = (hc.get("boundingRegions") or [{}])[0].get("pageNumber", 1)
                    items.append({
                        "key":        header_text,
                        "value":      vc["content"].strip(),
                        "confidence": 0.72,
                        "type":       f"Table-{ti+1} Row",
                        "page":       page,
                    })
    return items


def _extract_inline_patterns(ar: dict) -> list[dict]:
    """
    Parse paragraphs for inline 'Label: Value' or 'Label — Value' patterns.
    """
    PATTERNS = [
        re.compile(r"^(.{1,80}?)\s*[:：]\s*(.+)$"),          # Label: Value
        re.compile(r"^(.{1,80}?)\s*[—–-]{1,3}\s*(.+)$"),     # Label — Value
        re.compile(r"^(.{1,80}?)\s+(?:is|was|are|were)\s+(.+)$", re.I),  # Label is Value
    ]

    items = []
    for para in ar.get("paragraphs", []):
        text = para.get("content", "").strip()
        if not text or len(text) > 300:
            continue
        page = (para.get("boundingRegions") or [{}])[0].get("pageNumber", 1)
        for pat in PATTERNS:
            m = pat.match(text)
            if m:
                key_text = m.group(1).strip()
                val_text = m.group(2).strip()
                if len(key_text) > 2 and len(val_text) > 0:
                    items.append({
                        "key":        key_text,
                        "value":      val_text,
                        "confidence": 0.55,
                        "type":       "Inline Pattern",
                        "page":       page,
                    })
                break
    return items


# ── Matching ─────────────────────────────────────────────────────────────────

def _find_best_match(heading: str, corpus: list[dict], threshold: float) -> dict | None:
    """Find the corpus entry whose key best matches the heading."""
    h_norm = _normalize(heading)
    best = None
    best_score = -1.0

    for item in corpus:
        sim = _similarity(h_norm, _normalize(item["key"]))
        # Combined score: similarity × source confidence
        score = sim * item["confidence"]
        if score > best_score:
            best_score = score
            best = {**item, "score": score}

    if best_score < threshold:
        return None
    return best


def _normalize(text: str) -> str:
    """Lowercase, remove punctuation, collapse whitespace."""
    text = text.lower()
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _similarity(a: str, b: str) -> float:
    """
    Composite similarity: exact → contains → token Jaccard + prefix bonus.
    Returns value in [0, 1].
    """
    if not a or not b:
        return 0.0

    # Exact match
    if a == b:
        return 1.0

    # Substring containment
    if a in b or b in a:
        shorter = min(len(a), len(b))
        longer  = max(len(a), len(b))
        return 0.85 * (shorter / longer)

    # Token Jaccard similarity
    tokens_a = set(a.split())
    tokens_b = set(b.split())
    # Remove very common stop words for better discrimination
    stops = {"the","a","an","of","in","on","at","to","for","and","or","is","was","are"}
    tokens_a -= stops
    tokens_b -= stops

    intersection = tokens_a & tokens_b
    union = tokens_a | tokens_b
    jaccard = len(intersection) / len(union) if union else 0.0

    # Prefix bonus (first 4 chars)
    prefix_len = min(len(a), len(b), 4)
    prefix_bonus = 0.08 if prefix_len >= 2 and a[:prefix_len] == b[:prefix_len] else 0.0

    # Character n-gram similarity (trigrams)
    ngram_score = _ngram_similarity(a, b, n=3) * 0.3

    return min(jaccard * 0.7 + prefix_bonus + ngram_score, 1.0)


def _ngram_similarity(a: str, b: str, n: int = 3) -> float:
    """Character n-gram Jaccard similarity."""
    def ngrams(s):
        return set(s[i:i+n] for i in range(len(s) - n + 1))

    ng_a = ngrams(a)
    ng_b = ngrams(b)
    if not ng_a or not ng_b:
        return 0.0
    inter = ng_a & ng_b
    union = ng_a | ng_b
    return len(inter) / len(union)
