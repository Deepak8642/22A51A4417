"""
core/excel_reader.py — Read field headings from an Excel file.
"""

import re
from pathlib import Path
from utils.logger import get_logger

logger = get_logger(__name__)


def col_letter_to_index(letter: str) -> int:
    """Convert column letter (A, B, … Z, AA …) to 0-based index."""
    letter = letter.upper().strip()
    idx = 0
    for ch in letter:
        idx = idx * 26 + (ord(ch) - ord("A") + 1)
    return idx - 1


def read_headings_from_excel(
    path: str,
    sheet_name: str = None,
    col_letter: str = None,
    header_row: int = 1,
) -> list[str]:
    """
    Read unique, non-empty headings from an Excel file.

    Args:
        path:        Path to .xlsx or .xls file.
        sheet_name:  Sheet to read (None = first sheet).
        col_letter:  Column letter like 'A', 'B' (None = auto-detect best column).
        header_row:  1-based row to start reading from (skip rows above).

    Returns:
        List of unique heading strings in order.
    """
    try:
        import openpyxl
    except ImportError:
        raise ImportError("openpyxl is required: pip install openpyxl")

    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Excel file not found: {path}")

    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)

    # Sheet selection
    if sheet_name:
        if sheet_name not in wb.sheetnames:
            logger.warning(
                f"Sheet '{sheet_name}' not found. Available: {wb.sheetnames}. "
                f"Using first sheet."
            )
            ws = wb.active
        else:
            ws = wb[sheet_name]
    else:
        ws = wb.active
    logger.info(f"  Sheet: '{ws.title}'")

    # Read all rows into a list of lists
    all_rows = []
    for row in ws.iter_rows(min_row=header_row, values_only=True):
        all_rows.append(list(row))

    if not all_rows:
        return []

    # Determine column index
    if col_letter:
        col_idx = col_letter_to_index(col_letter)
        logger.info(f"  Using column: {col_letter.upper()} (index {col_idx})")
    else:
        col_idx = _auto_detect_column(all_rows)
        col_name = _index_to_col_letter(col_idx)
        logger.info(f"  Auto-detected column: {col_name} (index {col_idx})")

    # Extract values from that column
    headings = []
    for row in all_rows:
        if col_idx >= len(row):
            continue
        cell = row[col_idx]
        if cell is None:
            continue
        val = str(cell).strip()
        if val and len(val) > 1 and not _is_noise(val):
            headings.append(val)

    # Deduplicate preserving order
    seen = set()
    unique = []
    for h in headings:
        if h not in seen:
            seen.add(h)
            unique.append(h)

    wb.close()
    return unique


def _auto_detect_column(rows: list) -> int:
    """
    Heuristically find the column most likely to contain field headings.
    Prefers columns with many short-to-medium length strings.
    """
    if not rows:
        return 0

    max_cols = max(len(r) for r in rows)
    scores = {}

    for ci in range(max_cols):
        values = [r[ci] for r in rows if ci < len(r) and r[ci] is not None]
        str_values = [str(v).strip() for v in values if str(v).strip()]
        if not str_values:
            continue
        # Score: prefer columns with many string values of sensible lengths
        count = len(str_values)
        avg_len = sum(len(v) for v in str_values) / count
        # Ideal heading length is 5–60 chars; penalize very long or very short
        length_score = 1.0 if 5 <= avg_len <= 60 else 0.5
        scores[ci] = count * length_score

    if not scores:
        return 0
    return max(scores, key=scores.get)


def _index_to_col_letter(idx: int) -> str:
    """Convert 0-based column index to Excel column letter."""
    result = ""
    idx += 1
    while idx:
        idx, rem = divmod(idx - 1, 26)
        result = chr(65 + rem) + result
    return result


def _is_noise(val: str) -> bool:
    """Filter out values that are clearly not headings."""
    # Pure numbers
    try:
        float(val.replace(",", ""))
        return True
    except ValueError:
        pass
    # Very short or single special chars
    if re.match(r"^[\W\d]+$", val):
        return True
    return False
